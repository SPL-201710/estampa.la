import Ember from 'ember';

export function js(params/*, hash*/) {
  return params;
}

export default Ember.Helper.helper(js);
