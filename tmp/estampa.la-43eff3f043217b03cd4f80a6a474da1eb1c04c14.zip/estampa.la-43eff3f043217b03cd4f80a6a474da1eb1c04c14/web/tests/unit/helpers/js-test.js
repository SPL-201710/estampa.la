
import { js } from 'estampala/helpers/js';
import { module, test } from 'qunit';

module('Unit | Helper | js');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = js([42]);
  assert.ok(result);
});

