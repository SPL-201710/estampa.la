package catalog.models.print;

public enum Fonts {

}
