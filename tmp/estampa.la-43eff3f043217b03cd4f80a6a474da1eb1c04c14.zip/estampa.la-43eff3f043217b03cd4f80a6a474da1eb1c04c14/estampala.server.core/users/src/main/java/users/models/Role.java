package users.models;

public enum Role {
	USER, ADMIN, ARTIST
}
