package commons.responses;

import org.springframework.http.HttpStatus;

public class SuccessResponse implements EstampalaResponse{

	private boolean success;
	private String message;
	private HttpStatus httpStatus;
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}	
}
